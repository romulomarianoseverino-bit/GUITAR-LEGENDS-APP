package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.guitarlegends.analysis.AdaptiveEngine
import com.example.guitarlegends.analysis.AudioAnalyzer
import com.example.guitarlegends.model.*
import com.example.guitarlegends.viewmodel.GameViewModel
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Guitar Legends", appName)
    }

    @Test
    fun `test GLAS operates correctly in Easy difficulty without breaking or invading medium bounds`() {
        val easyEngineDisabled = AdaptiveEngine(baseDifficulty = Difficulty.EASY, isEnabled = false)
        assertEquals(Difficulty.EASY.hitWindowMs, easyEngineDisabled.getEffectiveHitWindowMs())
        assertEquals(0.08f, easyEngineDisabled.getMissPenalty(), 0.001f)

        val easyEngineEnabled = AdaptiveEngine(baseDifficulty = Difficulty.EASY, isEnabled = true)
        // Check initial window
        val initialWindow = easyEngineEnabled.getEffectiveHitWindowMs()
        assertTrue("Easy window should be at least 165ms", initialWindow >= 165L)
        assertTrue("Easy window should not exceed 240ms", initialWindow <= 240L)
        // Easy miss penalty should be protected (0.04f vs 0.08f)
        assertEquals(0.04f, easyEngineEnabled.getMissPenalty(), 0.001f)

        // Simulate 20 perfect notes - window should remain strictly within Easy boundaries (>= 165ms)
        for (i in 1..20) {
            easyEngineEnabled.onNoteResult(HitRating.PERFECT, 10L)
        }
        val tightWindow = easyEngineEnabled.getEffectiveHitWindowMs()
        assertTrue("Tightened window on Easy must stay >= 165ms (never invade Medium 140ms)", tightWindow >= 165L)
        assertTrue("Status text should indicate Easy", easyEngineEnabled.statusText.contains("Fácil"))

        // Simulate 5 consecutive misses - assistance should expand window up to max 240ms
        for (i in 1..5) {
            easyEngineEnabled.onNoteResult(HitRating.MISS, 0L)
        }
        val assistedWindow = easyEngineEnabled.getEffectiveHitWindowMs()
        assertTrue("Assisted window must expand for beginners", assistedWindow >= 180L)
        assertTrue("Assisted window must not exceed max boundary", assistedWindow <= 240L)
    }

    @Test
    fun `test all four difficulties have distinct, strictly bounded GLAS ranges`() {
        for (diff in Difficulty.values()) {
            val engine = AdaptiveEngine(baseDifficulty = diff, isEnabled = true)
            val window = engine.getEffectiveHitWindowMs()
            assertTrue(window >= engine.minHitWindowMs)
            assertTrue(window <= engine.maxHitWindowMs)
        }
    }

    @Test
    fun `test note chart generation for all four instruments across difficulties`() {
        val track = AudioAnalyzer.BUILT_IN_TRACKS[0]

        for (inst in Instrument.values()) {
            for (diff in Difficulty.values()) {
                val chart = AudioAnalyzer.generateChart(track, inst, diff)
                assertTrue("Chart for $inst at $diff should not be empty", chart.isNotEmpty())
                // Ensure all notes are within valid lane range for that difficulty
                val maxAllowedLane = diff.lanesUsed - 1
                for (note in chart) {
                    assertTrue("Note lane ${note.lane} must be in 0..$maxAllowedLane", note.lane in 0..maxAllowedLane)
                }
            }
        }
    }

    @Test
    fun `test character creator, styles, instrument gear and highway theme selection in ViewModel`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = GameViewModel(app)

        // Verify initial state
        assertNotNull(vm.playerStats.value)
        assertEquals("theme_ps2_wood", vm.playerStats.value.selectedHighwayThemeId)

        // Equip custom character and change art style
        vm.updateCustomRockerMethod(CharacterCreationMethod.PRESERVE_FACIAL_FEATURES)
        assertEquals(CharacterCreationMethod.PRESERVE_FACIAL_FEATURES, vm.playerStats.value.customRocker.creationMethod)

        vm.updateCustomRockerStyle(CharacterArtStyle.CARTOON)
        assertEquals(CharacterArtStyle.CARTOON, vm.playerStats.value.customRocker.artStyle)

        vm.updateCustomRockerAppearance(
            hair = "Metalhead Longo",
            top = "Colete Jeans c/ Patches",
            pants = "Calça Jeans Rasgada",
            shoes = "Coturnos Militares",
            accessories = "Munhequeiras c/ Espinhos",
            tattoos = "Caveiras nos Braços"
        )
        assertEquals("Metalhead Longo", vm.playerStats.value.customRocker.hairStyle)

        // Equip gear across all instruments
        vm.selectGear(Instrument.GUITAR, "neon_thunder")
        assertEquals("neon_thunder", vm.playerStats.value.selectedGuitarId)

        vm.selectGear(Instrument.BASS, "skull_bass")
        assertEquals("skull_bass", vm.playerStats.value.selectedBassId)

        vm.selectGear(Instrument.DRUMS, "punk_garage_kit")
        assertEquals("punk_garage_kit", vm.playerStats.value.selectedDrumsId)

        vm.selectGear(Instrument.VOCALS, "golden_supreme_mic")
        assertEquals("golden_supreme_mic", vm.playerStats.value.selectedVocalMicId)

        // Equip highway theme
        vm.equipHighwayTheme("theme_neon_cyber")
        assertEquals("theme_neon_cyber", vm.playerStats.value.selectedHighwayThemeId)
    }
}
