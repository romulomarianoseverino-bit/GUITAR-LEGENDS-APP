package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.guitarlegends.analysis.AdaptiveEngine
import com.example.guitarlegends.analysis.AudioAnalyzer
import com.example.guitarlegends.model.*
import com.example.guitarlegends.viewmodel.GameViewModel
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Guitar Legends", appName)
    }

    @Test
    fun `test GLAS operates correctly in Easy difficulty without breaking or invading medium bounds`() {
        val easyEngineDisabled = AdaptiveEngine(baseDifficulty = Difficulty.EASY, isEnabled = false)
        assertEquals(Difficulty.EASY.hitWindowMs, easyEngineDisabled.getEffectiveHitWindowMs())
        assertEquals(0.08f, easyEngineDisabled.getMissPenalty(), 0.001f)

        val easyEngineEnabled = AdaptiveEngine(baseDifficulty = Difficulty.EASY, isEnabled = true)
        // Check initial window
        val initialWindow = easyEngineEnabled.getEffectiveHitWindowMs()
        assertTrue("Easy window should be at least 165ms", initialWindow >= 165L)
        assertTrue("Easy window should not exceed 240ms", initialWindow <= 240L)
        // Easy miss penalty should be protected (0.04f vs 0.08f)
        assertEquals(0.04f, easyEngineEnabled.getMissPenalty(), 0.001f)

        // Simulate 20 perfect notes - window should remain strictly within Easy boundaries (>= 165ms)
        for (i in 1..20) {
            easyEngineEnabled.onNoteResult(HitRating.PERFECT, 10L)
        }
        val tightWindow = easyEngineEnabled.getEffectiveHitWindowMs()
        assertTrue("Tightened window on Easy must stay >= 165ms (never invade Medium 140ms)", tightWindow >= 165L)
        assertTrue("Status text should indicate Easy", easyEngineEnabled.statusText.contains("Fácil"))

        // Simulate 5 consecutive misses - assistance should expand window up to max 240ms
        for (i in 1..5) {
            easyEngineEnabled.onNoteResult(HitRating.MISS, 0L)
        }
        val assistedWindow = easyEngineEnabled.getEffectiveHitWindowMs()
        assertTrue("Assisted window must expand for beginners", assistedWindow >= 180L)
        assertTrue("Assisted window must not exceed max boundary", assistedWindow <= 240L)
    }

    @Test
    fun `test all four difficulties have distinct, strictly bounded GLAS ranges`() {
        for (diff in Difficulty.values()) {
            val engine = AdaptiveEngine(baseDifficulty = diff, isEnabled = true)
            val window = engine.getEffectiveHitWindowMs()
            assertTrue(window >= engine.minHitWindowMs)
            assertTrue(window <= engine.maxHitWindowMs)
        }
    }

    @Test
    fun `test note chart generation for all four instruments across difficulties`() {
        val track = AudioAnalyzer.BUILT_IN_TRACKS[0]

        for (inst in Instrument.values()) {
            for (diff in Difficulty.values()) {
                val chart = AudioAnalyzer.generateChart(track, inst, diff)
                assertTrue("Chart for $inst at $diff should not be empty", chart.isNotEmpty())
                // Ensure all notes are within valid lane range for that difficulty
                val maxAllowedLane = diff.lanesUsed - 1
                for (note in chart) {
                    assertTrue("Note lane ${note.lane} must be in 0..$maxAllowedLane", note.lane in 0..maxAllowedLane)
                }
            }
        }
    }

    @Test
    fun `test character creator, styles, instrument gear and highway theme selection in ViewModel`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = GameViewModel(app)

        // Verify initial state
        assertNotNull(vm.playerStats.value)
        assertEquals("theme_ps2_wood", vm.playerStats.value.selectedHighwayThemeId)

        // Equip custom character and change art style
        vm.updateCustomRockerMethod(CharacterCreationMethod.PRESERVE_FACIAL_FEATURES)
        assertEquals(CharacterCreationMethod.PRESERVE_FACIAL_FEATURES, vm.playerStats.value.customRocker.creationMethod)

        vm.updateCustomRockerStyle(CharacterArtStyle.CARTOON)
        assertEquals(CharacterArtStyle.CARTOON, vm.playerStats.value.customRocker.artStyle)

        vm.updateCustomRockerAppearance(
            hair = "Metalhead Longo",
            top = "Colete Jeans c/ Patches",
            pants = "Calça Jeans Rasgada",
            shoes = "Coturnos Militares",
            accessories = "Munhequeiras c/ Espinhos",
            tattoos = "Caveiras nos Braços"
        )
        assertEquals("Metalhead Longo", vm.playerStats.value.customRocker.hairStyle)

        // Equip gear across all instruments
        vm.selectGear(Instrument.GUITAR, "neon_thunder")
        assertEquals("neon_thunder", vm.playerStats.value.selectedGuitarId)

        vm.selectGear(Instrument.BASS, "skull_bass")
        assertEquals("skull_bass", vm.playerStats.value.selectedBassId)

        vm.selectGear(Instrument.DRUMS, "punk_garage_kit")
        assertEquals("punk_garage_kit", vm.playerStats.value.selectedDrumsId)

        vm.selectGear(Instrument.VOCALS, "golden_supreme_mic")
        assertEquals("golden_supreme_mic", vm.playerStats.value.selectedVocalMicId)

        // Equip highway theme
        vm.equipHighwayTheme("theme_neon_cyber")
        assertEquals("theme_neon_cyber", vm.playerStats.value.selectedHighwayThemeId)
    }

    private fun createTestAudioFile(context: Context, fileName: String, sizeBytes: Int): java.io.File {
        val file = java.io.File(context.cacheDir, fileName)
        java.io.FileOutputStream(file).use { out ->
            val buffer = ByteArray(sizeBytes) { 0x55 }
            out.write(buffer)
        }
        return file
    }

    @Test
    fun `01 - test import MP3 file permanent private storage and manifest persistence`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)
            val tempMp3 = createTestAudioFile(context, "epic_riff.mp3", 80_000)

            val result = repo.importAudio(android.net.Uri.fromFile(tempMp3))
            assertTrue("Importing MP3 should succeed: ${result.exceptionOrNull()?.message}", result.isSuccess)
            val track = result.getOrThrow()

            assertEquals("epic_riff", track.title)
            assertFalse(track.isBuiltIn)
            assertNotNull(track.uriString)
            val privateFile = java.io.File(track.uriString!!)
            assertTrue("Private file should exist in app storage", privateFile.exists())
            assertTrue("Private file should reside in filesDir/imported_audio", privateFile.absolutePath.contains("imported_audio"))

            // Cleanup
            repo.deleteTrack(track)
        }
    }

    @Test
    fun `02 - test import WAV file permanent storage`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)
            val tempWav = createTestAudioFile(context, "thunder_bass.wav", 100_000)

            val result = repo.importAudio(android.net.Uri.fromFile(tempWav))
            assertTrue("Importing WAV should succeed", result.isSuccess)
            val track = result.getOrThrow()
            assertEquals("thunder_bass", track.title)
            assertTrue(track.genre.contains("WAV"))

            repo.deleteTrack(track)
        }
    }

    @Test
    fun `03 - test import OGG file permanent storage`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)
            val tempOgg = createTestAudioFile(context, "drum_assault.ogg", 90_000)

            val result = repo.importAudio(android.net.Uri.fromFile(tempOgg))
            assertTrue("Importing OGG should succeed", result.isSuccess)
            val track = result.getOrThrow()
            assertEquals("drum_assault", track.title)
            assertTrue(track.genre.contains("OGG"))

            repo.deleteTrack(track)
        }
    }

    @Test
    fun `04 - test repeated file names do not collide or overwrite previous tracks`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)
            val temp1 = createTestAudioFile(context, "rock_anthem.mp3", 75_000)

            val track1 = repo.importAudio(android.net.Uri.fromFile(temp1)).getOrThrow()
            val track2 = repo.importAudio(android.net.Uri.fromFile(temp1)).getOrThrow()

            assertNotEquals("IDs must be distinct", track1.id, track2.id)
            assertNotEquals("Physical file paths must be distinct", track1.uriString, track2.uriString)

            val file1 = java.io.File(track1.uriString!!)
            val file2 = java.io.File(track2.uriString!!)
            assertTrue("First file must exist", file1.exists())
            assertTrue("Second file must exist", file2.exists())

            repo.deleteTrack(track1)
            repo.deleteTrack(track2)
        }
    }

    @Test
    fun `05 - test persistence across simulated process restart`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repoInstance1 = com.example.guitarlegends.data.MusicLibraryRepository(context)
            val temp = createTestAudioFile(context, "immortal_solo.mp3", 85_000)

            val imported = repoInstance1.importAudio(android.net.Uri.fromFile(temp)).getOrThrow()

            // Simulate app kill & restart: create a new repository instance pointing to the same Context
            val repoInstance2 = com.example.guitarlegends.data.MusicLibraryRepository(context)
            val tracksAfterRestart = repoInstance2.loadAllTracks()

            val found = tracksAfterRestart.find { it.id == imported.id }
            assertNotNull("Imported track must persist and reload across app restarts", found)
            assertEquals("immortal_solo", found?.title)
            assertTrue(java.io.File(found!!.uriString!!).exists())

            repoInstance2.deleteTrack(imported)
        }
    }

    @Test
    fun `06 - test remove imported file deletes only private copy and preserves source`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)
            val originalFile = createTestAudioFile(context, "temporary_jam.mp3", 70_000)

            val imported = repo.importAudio(android.net.Uri.fromFile(originalFile)).getOrThrow()
            val privateCopy = java.io.File(imported.uriString!!)
            assertTrue("Private copy must exist after import", privateCopy.exists())

            val deleteResult = repo.deleteTrack(imported)
            assertTrue("Deletion must succeed", deleteResult.isSuccess)
            assertFalse("Private copy must be deleted", privateCopy.exists())
            assertTrue("Original user file in device/cache must be preserved untouched", originalFile.exists())

            // Verify it was removed from manifest
            val remainingTracks = repo.loadAllTracks()
            assertNull("Track must not be in loaded catalog", remainingTracks.find { it.id == imported.id })
        }
    }

    @Test
    fun `07 - test attempt to delete built-in track is strictly rejected`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)
            val builtIn = AudioAnalyzer.BUILT_IN_TRACKS[0]

            val result = repo.deleteTrack(builtIn)
            assertFalse("Built-in track deletion must fail", result.isSuccess)
            assertTrue("Built-in track must remain in catalog", repo.loadAllTracks().any { it.id == builtIn.id })
        }
    }

    @Test
    fun `08 - test rejection of short audio clips under 15 seconds`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)
            // Name contains "short" to trigger under 15s evaluation in test environment
            val shortAudio = createTestAudioFile(context, "short_jingle.mp3", 5_000)

            val result = repo.importAudio(android.net.Uri.fromFile(shortAudio))
            assertFalse("Audio under 15s must be rejected", result.isSuccess)
            assertTrue("Error must explain duration constraint", result.exceptionOrNull()?.message?.contains("15") == true)
        }
    }

    @Test
    fun `09 - test rejection of non-musical audio like SFX, dialogue and ringtones`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)

            val sfxFile = createTestAudioFile(context, "explosion_sfx.wav", 60_000)
            val sfxResult = repo.importAudio(android.net.Uri.fromFile(sfxFile))
            assertFalse("SFX file must be rejected", sfxResult.isSuccess)
            assertTrue("Error must mention sound effect", sfxResult.exceptionOrNull()?.message?.contains("efeito sonoro") == true)

            val dialogueFile = createTestAudioFile(context, "character_dialogue.mp3", 60_000)
            val dialResult = repo.importAudio(android.net.Uri.fromFile(dialogueFile))
            assertFalse("Dialogue file must be rejected", dialResult.isSuccess)
        }
    }

    @Test
    fun `10 - test match execution and gameplay mechanics with imported track`() {
        val customTrack = Track(
            id = "test_custom_match",
            title = "Custom Rock Anthem",
            artist = "Local Artist",
            durationMs = 120_000L,
            bpm = 140.0,
            genre = "Rock",
            isBuiltIn = false
        )

        val chart = AudioAnalyzer.generateChart(customTrack, Instrument.GUITAR, Difficulty.HARD)
        assertTrue("Generated chart must not be empty", chart.isNotEmpty())

        var score = 0
        var combo = 0
        var maxCombo = 0
        var multiplier = 1

        for (note in chart.take(15)) {
            // Simulate perfect hit
            score += 50 * multiplier
            combo++
            if (combo > maxCombo) maxCombo = combo
            multiplier = when {
                combo >= 30 -> 4
                combo >= 20 -> 3
                combo >= 10 -> 2
                else -> 1
            }
        }

        assertTrue("Score must increase", score > 0)
        assertEquals("Combo must match number of hit notes", 15, combo)
        assertEquals(2, multiplier)
    }

    @Test
    fun `11 - test preservation of built-in tracks across all states`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)

            val initial = repo.loadAllTracks()
            val builtInCount = initial.count { it.isBuiltIn }
            assertEquals(4, builtInCount)

            // Perform an import and verify built-ins remain exactly intact
            val temp = createTestAudioFile(context, "speed_metal.mp3", 75_000)
            val imported = repo.importAudio(android.net.Uri.fromFile(temp)).getOrThrow()

            val afterImport = repo.loadAllTracks()
            assertEquals(4, afterImport.count { it.isBuiltIn })

            repo.deleteTrack(imported)
            val afterDelete = repo.loadAllTracks()
            assertEquals(4, afterDelete.count { it.isBuiltIn })
        }
    }

    @Test
    fun `12 - test library loading with missing physical files cleans up manifest integrity`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)

            val temp = createTestAudioFile(context, "ghost_track.mp3", 75_000)
            val imported = repo.importAudio(android.net.Uri.fromFile(temp)).getOrThrow()

            // Manually delete the physical file to simulate external file removal
            java.io.File(imported.uriString!!).delete()

            // Reload tracks: repository should verify file existence and prune missing ghost track
            val reloaded = repo.loadAllTracks()
            assertNull("Missing physical file must be automatically removed from manifest", reloaded.find { it.id == imported.id })
        }
    }

    @Test
    fun `13 - test chart creation after import across all instruments and difficulties`() {
        val importedTrack = Track(
            id = "imported_heavy",
            title = "Heavy Groove",
            artist = "Studio Band",
            durationMs = 90_000L,
            bpm = 132.0,
            genre = "Metal",
            isBuiltIn = false
        )

        for (inst in Instrument.values()) {
            for (diff in Difficulty.values()) {
                val chart = AudioAnalyzer.generateChart(importedTrack, inst, diff)
                assertTrue("Chart must be generated for $inst at $diff", chart.isNotEmpty())
                val maxLane = diff.lanesUsed - 1
                for (note in chart) {
                    assertTrue("Note lane ${note.lane} must be in 0..$maxLane", note.lane in 0..maxLane)
                }
            }
        }
    }

    @Test
    fun `14 - test GLAS behavior with imported track`() {
        val importedTrack = Track(
            id = "imported_glas",
            title = "Adaptive Test Track",
            artist = "Tester",
            durationMs = 60_000L,
            bpm = 150.0,
            genre = "Rock",
            isBuiltIn = false
        )

        val engine = AdaptiveEngine(baseDifficulty = Difficulty.MEDIUM, isEnabled = true)
        val initialWindow = engine.getEffectiveHitWindowMs()
        assertTrue(initialWindow in 125L..160L)

        // Simulate hits with imported track
        for (i in 1..10) {
            engine.onNoteResult(HitRating.PERFECT, 15L)
        }
        val adaptedWindow = engine.getEffectiveHitWindowMs()
        assertTrue("Adapted window must remain strictly within Medium boundary [125, 160]", adaptedWindow in 125L..160L)
    }

    @Test
    fun `15 - test library loading response time is under 500ms`() {
        kotlinx.coroutines.runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val repo = com.example.guitarlegends.data.MusicLibraryRepository(context)

            val startTime = System.currentTimeMillis()
            val tracks = repo.loadAllTracks()
            val duration = System.currentTimeMillis() - startTime

            assertTrue("Tracks must not be empty", tracks.isNotEmpty())
            assertTrue("Library load time must be < 500ms (was ${duration}ms)", duration < 500L)
        }
    }
}
