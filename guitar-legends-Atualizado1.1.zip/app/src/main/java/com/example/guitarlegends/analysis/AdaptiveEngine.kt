package com.example.guitarlegends.analysis

import com.example.guitarlegends.model.Difficulty
import com.example.guitarlegends.model.HitRating

/**
 * Guitar Legends Adaptive System (GLAS)
 * Sistema adaptativo que avalia o desempenho em tempo real e calibra dinamicamente
 * as janelas de precisão e tolerância sem nunca distorcer a velocidade do áudio
 * e respeitando rigorosamente os limites estritos da dificuldade escolhida.
 */
class AdaptiveEngine(
    val baseDifficulty: Difficulty,
    val isEnabled: Boolean = true
) {
    var consecutiveHits = 0
        private set
    var consecutiveMisses = 0
        private set
    var totalEvaluated = 0
        private set
    var perfectCount = 0
        private set

    // Escala adaptativa de -1.0f (Assistência Dinâmica) a +1.0f (Modo Virtuoso)
    var adaptiveIndex: Float = 0.0f
        private set

    // Limites rígidos de janela por dificuldade para impedir invasão entre dificuldades
    val minHitWindowMs: Long
    val maxHitWindowMs: Long

    init {
        when (baseDifficulty) {
            Difficulty.EASY -> {
                // Fácil: Base 180ms. Janela NUNCA desce para 140ms (Médio).
                // Varia de 165ms a 240ms, garantindo que iniciantes nunca sejam frustrados.
                minHitWindowMs = 165L
                maxHitWindowMs = 240L
            }
            Difficulty.MEDIUM -> {
                // Médio: Base 140ms. Varia estritamente de 125ms a 160ms.
                minHitWindowMs = 125L
                maxHitWindowMs = 160L
            }
            Difficulty.HARD -> {
                // Difícil: Base 100ms. Varia estritamente de 85ms a 120ms.
                minHitWindowMs = 85L
                maxHitWindowMs = 120L
            }
            Difficulty.EXPERT -> {
                // Expert: Base 70ms. Varia estritamente de 55ms a 84ms.
                minHitWindowMs = 55L
                maxHitWindowMs = 84L
            }
        }
    }

    val statusText: String
        get() {
            if (!isEnabled) return "GLAS: Desativado (${baseDifficulty.displayName})"
            return when {
                adaptiveIndex > 0.40f -> "GLAS [${baseDifficulty.displayName}]: Modo Virtuoso (+Bônus)"
                adaptiveIndex < -0.30f -> "GLAS [${baseDifficulty.displayName}]: Assistência Dinâmica (+Janela)"
                else -> "GLAS [${baseDifficulty.displayName}]: Ritmo Equilibrado"
            }
        }

    fun onNoteResult(rating: HitRating, deltaMs: Long) {
        if (!isEnabled) return
        totalEvaluated++

        when (rating) {
            HitRating.PERFECT -> {
                perfectCount++
                consecutiveHits++
                consecutiveMisses = 0
                val step = if (baseDifficulty == Difficulty.EASY) 0.02f else 0.035f
                if (consecutiveHits >= 10) {
                    adaptiveIndex = (adaptiveIndex + step).coerceAtMost(1.0f)
                }
            }
            HitRating.GREAT, HitRating.GOOD -> {
                consecutiveHits++
                consecutiveMisses = 0
                val step = if (baseDifficulty == Difficulty.EASY) 0.01f else 0.018f
                if (consecutiveHits >= 18) {
                    adaptiveIndex = (adaptiveIndex + step).coerceAtMost(0.5f)
                }
            }
            HitRating.MISS -> {
                consecutiveHits = 0
                consecutiveMisses++
                val missThreshold = if (baseDifficulty == Difficulty.EASY) 2 else 3
                val dropStep = if (baseDifficulty == Difficulty.EASY) 0.15f else 0.08f
                if (consecutiveMisses >= missThreshold) {
                    adaptiveIndex = (adaptiveIndex - dropStep).coerceIn(-1.0f, 1.0f)
                }
            }
        }
    }

    /**
     * Retorna a janela de tolerância de impacto em milissegundos respeitando os limites estritos
     * da dificuldade base selecionada. No modo Fácil, jamais invade o modo Médio.
     */
    fun getEffectiveHitWindowMs(): Long {
        val base = baseDifficulty.hitWindowMs
        if (!isEnabled) return base
        val delta = (-adaptiveIndex * (if (baseDifficulty == Difficulty.EASY) 25f else 20f)).toLong()
        return (base + delta).coerceIn(minHitWindowMs, maxHitWindowMs)
    }

    /**
     * Modificador de penalidade de Rock Meter ao errar:
     * No modo Fácil com GLAS, a penalidade por erro é reduzida pela metade para proteger iniciantes.
     */
    fun getMissPenalty(): Float {
        if (!isEnabled) return 0.08f
        return when (baseDifficulty) {
            Difficulty.EASY -> 0.04f // Proteção para Fácil
            Difficulty.MEDIUM -> 0.065f
            Difficulty.HARD -> 0.08f
            Difficulty.EXPERT -> 0.095f
        }
    }

    /**
     * Bônus multiplicador de pontuação para sequências perfeitas sob GLAS
     */
    fun getScoreBoost(): Float {
        if (!isEnabled) return 1.0f
        return 1.0f + (adaptiveIndex * 0.12f).coerceAtLeast(0f)
    }

    fun reset() {
        consecutiveHits = 0
        consecutiveMisses = 0
        totalEvaluated = 0
        perfectCount = 0
        adaptiveIndex = 0.0f
    }
}
