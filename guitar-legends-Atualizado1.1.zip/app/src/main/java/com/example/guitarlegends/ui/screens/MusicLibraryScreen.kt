package com.example.guitarlegends.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.guitarlegends.model.Track
import com.example.guitarlegends.ui.components.*
import com.example.guitarlegends.viewmodel.GameScreen
import com.example.guitarlegends.viewmodel.GameViewModel

@Composable
fun MusicLibraryScreen(viewModel: GameViewModel) {
    BackHandler {
        viewModel.stopPreview()
        viewModel.navigateBack()
    }

    val stats by viewModel.playerStats.collectAsState()
    val tracks by viewModel.tracks.collectAsState()
    val isImporting by viewModel.isImportingAudio.collectAsState()
    val libraryError by viewModel.libraryErrorMessage.collectAsState()
    val isPreviewPlaying by viewModel.isPreviewPlaying.collectAsState()
    val previewTrackId by viewModel.previewTrackId.collectAsState()

    var trackToDelete by remember { mutableStateOf<Track?>(null) }

    // Android SAF zero-permission audio file picker
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importAudioFile(uri)
        }
    }

    // Modal de Confirmação para Remoção Segura de Música
    if (trackToDelete != null) {
        val target = trackToDelete!!
        AlertDialog(
            onDismissRequest = { trackToDelete = null },
            title = {
                Text(
                    text = "Remover Música da Biblioteca?",
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontSize = 16.sp
                )
            },
            text = {
                Text(
                    text = "A cópia de '${target.title}' armazenada na biblioteca privada do Guitar Legends será excluída.\n\nO arquivo de áudio original armazenado no seu celular NÃO será afetado ou apagado.",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteImportedTrack(target)
                        trackToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RockAccentRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("REMOVER DA BIBLIOTECA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { trackToDelete = null }) {
                    Text("CANCELAR", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            },
            containerColor = RockDarkCard,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Modal de Aviso de Erro / Filtro de Conteúdo Não-Musical
    if (libraryError != null) {
        AlertDialog(
            onDismissRequest = { viewModel.clearLibraryError() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = RockAccentRed, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Aviso da Biblioteca",
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                }
            },
            text = {
                Text(
                    text = libraryError ?: "",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.clearLibraryError() },
                    colors = ButtonDefaults.buttonColors(containerColor = RockAccentCyan),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("ENTENDI", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            },
            containerColor = RockDarkCard,
            shape = RoundedCornerShape(16.dp)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RockPurpleBg)
    ) {
        TopStatusBar(
            coins = stats.coins,
            stars = stats.unlockedStars,
            onBackClick = {
                viewModel.stopPreview()
                viewModel.navigateBack()
            },
            title = "Biblioteca Musical — Faixas & Áudios"
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            // Left list of tracks
            Column(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
            ) {
                // Header with Import Button & Progress
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MÚSICAS DISPONÍVEIS (${tracks.size})",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Button(
                        onClick = { audioPickerLauncher.launch("audio/*") },
                        enabled = !isImporting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RockAccentCyan,
                            disabledContainerColor = Color.DarkGray
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("import_audio_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isImporting) "COPIANDO..." else "IMPORTAR DO CELULAR",
                            color = Color.Black,
                            fontWeight = FontWeight.Black,
                            fontSize = 10.sp
                        )
                    }
                }

                // Barra de carregamento visual ao importar
                if (isImporting) {
                    Surface(
                        color = Color(0x3300E5FF),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = RockAccentCyan,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Salvando cópia privada e analisando mapa de notas...",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(tracks) { track ->
                        val isSelected = track.id == viewModel.selectedTrack.id
                        val isTrackPreviewing = isPreviewPlaying && previewTrackId == track.id

                        TrackItemCard(
                            track = track,
                            isSelected = isSelected,
                            isPreviewPlaying = isTrackPreviewing,
                            onSelect = {
                                viewModel.selectTrack(track)
                            },
                            onDelete = if (!track.isBuiltIn) {
                                { trackToDelete = track }
                            } else null
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Detail & Action Pane
            val selected = viewModel.selectedTrack
            Card(
                modifier = Modifier
                    .weight(0.9f)
                    .fillMaxHeight(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = RockDarkCard),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.verticalGradient(listOf(RockAccentGold, RockCardBorder))
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (selected.isBuiltIn) RockAccentRed else RockAccentCyan,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (selected.isBuiltIn) "FAIXA ORIGINAL ROCK" else "CÓPIA LOCAL PERMANENTE",
                                    color = if (selected.isBuiltIn) Color.White else Color.Black,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }

                            if (!selected.isBuiltIn) {
                                IconButton(
                                    onClick = { trackToDelete = selected },
                                    modifier = Modifier.size(28.dp).testTag("delete_selected_track_button")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remover", tint = RockAccentRed.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = selected.title,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            maxLines = 2
                        )
                        Text(
                            text = selected.artist,
                            color = RockAccentCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 2.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Track Metadata Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MetaBadge(label = "BPM", value = "${selected.bpm.toInt()}")
                            MetaBadge(label = "DURAÇÃO", value = formatTime(selected.durationMs))
                            MetaBadge(label = "FORMATO", value = selected.genre.take(12))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Botão de Ouvir Prévia do Áudio
                        val isThisPreviewing = isPreviewPlaying && previewTrackId == selected.id
                        Button(
                            onClick = { viewModel.togglePreview(selected) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isThisPreviewing) RockAccentGold else Color(0x33FFFFFF)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("toggle_preview_button"),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (isThisPreviewing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (isThisPreviewing) Color.Black else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isThisPreviewing) "PAUSAR PRÉVIA" else "OUVIR PRÉVIA DO ÁUDIO",
                                color = if (isThisPreviewing) Color.Black else Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "ANÁLISE RÍTMICA GLAS",
                            color = Color.White.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "Mapas de notas gerados e calibrados para Guitarra, Baixo, Bateria e Vocal com áudio sincronizado.",
                            color = Color.White.copy(alpha = 0.5f),
                            fontSize = 9.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        RockButton(
                            text = "ESCOLHER INSTRUMENTO ▶",
                            onClick = {
                                viewModel.stopPreview()
                                viewModel.navigateTo(GameScreen.InstrumentSelect)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "proceed_to_instrument_button",
                            containerColor = RockAccentGreen,
                            contentColor = Color.Black
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TrackItemCard(
    track: Track,
    isSelected: Boolean,
    isPreviewPlaying: Boolean = false,
    onSelect: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("track_item_${track.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF2C194D) else RockDarkCard
        ),
        border = if (isSelected) ButtonDefaults.outlinedButtonBorder.copy(
            brush = Brush.horizontalGradient(listOf(RockAccentGold, RockAccentRed))
        ) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    color = if (isSelected) RockAccentGold else Color(0x33FFFFFF),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isPreviewPlaying) Icons.Default.VolumeUp
                            else if (track.isBuiltIn) Icons.Default.MusicNote
                            else Icons.Default.SdStorage,
                            contentDescription = null,
                            tint = if (isSelected) Color.Black else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                    Text(
                        text = "${track.artist} • ${formatTime(track.durationMs)} • ${track.bpm.toInt()} BPM",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isSelected) {
                    Text(
                        text = "ESCOLHIDA",
                        color = RockAccentGold,
                        fontWeight = FontWeight.Black,
                        fontSize = 9.sp,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }

                if (onDelete != null) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp).testTag("delete_track_${track.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Remover da Biblioteca",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetaBadge(label: String, value: String) {
    Surface(
        color = Color(0x22FFFFFF),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = label, color = Color.White.copy(alpha = 0.6f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Text(text = value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
        }
    }
}

fun formatTime(durationMs: Long): String {
    val totalSec = durationMs / 1000L
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return String.format("%d:%02d", min, sec)
}
